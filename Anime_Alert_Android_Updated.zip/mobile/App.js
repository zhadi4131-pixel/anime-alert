import React, {useEffect,useState} from 'react';
import {SafeAreaView,View,Text,TextInput,TouchableOpacity,ScrollView,Linking,Alert,ActivityIndicator} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import {StatusBar} from 'expo-status-bar';
const API=process.env.EXPO_PUBLIC_API_URL||'http://10.0.2.2:8000';
Notifications.setNotificationHandler({handleNotification:async()=>({shouldShowAlert:true,shouldPlaySound:true,shouldSetBadge:false})});
export default function App(){
 const [watch,setWatch]=useState(['One Piece','Jujutsu Kaisen','Solo Leveling']),[query,setQuery]=useState(''),[news,setNews]=useState([]),[busy,setBusy]=useState(false),[tab,setTab]=useState('news');
 useEffect(()=>{(async()=>{let list=['One Piece','Jujutsu Kaisen','Solo Leveling'];const s=await AsyncStorage.getItem('watchlist');if(s){try{list=JSON.parse(s);setWatch(list);}catch(e){}}await pushRegister(list);await loadNews();})();},[]);
 async function pushRegister(list=watch){
  if(!Device.isDevice)return;
  try{let p=await Notifications.getPermissionsAsync();if(p.status!=='granted')p=await Notifications.requestPermissionsAsync();if(p.status!=='granted')return;
   const projectId=Constants.expoConfig?.extra?.eas?.projectId;
   const token=(await Notifications.getExpoPushTokenAsync(projectId&&projectId!=='REPLACE_WITH_EAS_PROJECT_ID'?{projectId}:undefined)).data;
   await fetch(`${API}/devices`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,watchlist:list})});
  }catch(e){console.log(e);}
 }
 async function save(list){setWatch(list);await AsyncStorage.setItem('watchlist',JSON.stringify(list));await pushRegister(list);}
 async function loadNews(){setBusy(true);try{const r=await fetch(`${API}/news`);if(!r.ok)throw Error();setNews(await r.json());}catch(e){Alert.alert('تعذّر تحميل الأخبار','تأكد من تشغيل الخادم وضبط عنوان API.');}setBusy(false);}
 function add(){let v=query.trim();if(v&&!watch.includes(v))save([...watch,v]);setQuery('');}
 const filtered=news.filter(n=>watch.some(w=>(n.title+' '+(n.summary||'')).toLowerCase().includes(w.toLowerCase())));
 const shown=tab==='watch'?filtered:news;
 return <SafeAreaView style={{flex:1,backgroundColor:'#0b0b12'}}><StatusBar style="light"/><ScrollView contentContainerStyle={{padding:20,paddingBottom:40}}>
 <Text style={{color:'#bd9aff',fontWeight:'800',letterSpacing:3}}>YOUR PERSONAL ANIME RADAR</Text><Text style={{color:'white',fontSize:32,fontWeight:'900',marginTop:5}}>ANIME ALERT</Text><Text style={{color:'#aaa',textAlign:'right',marginTop:5}}>كل جديد عن الأعمال التي تحبها.</Text>
 <View style={{flexDirection:'row',marginTop:20,backgroundColor:'#191925',padding:5,borderRadius:14}}>{[['news','آخر الأخبار'],['watch','أخبار متابعتي']].map(([k,v])=><TouchableOpacity key={k} onPress={()=>setTab(k)} style={{flex:1,padding:12,borderRadius:10,backgroundColor:tab===k?'#713bd1':'transparent'}}><Text style={{color:'white',textAlign:'center'}}>{v}</Text></TouchableOpacity>)}</View>
 <View style={{marginTop:20,backgroundColor:'#191925',padding:15,borderRadius:16}}><Text style={{color:'white',fontSize:18,fontWeight:'800',textAlign:'right'}}>قائمة متابعتي</Text><View style={{flexDirection:'row',marginTop:12}}><TouchableOpacity onPress={add} style={{backgroundColor:'#713bd1',padding:13,borderRadius:10,marginRight:8}}><Text style={{color:'white'}}>إضافة</Text></TouchableOpacity><TextInput value={query} onChangeText={setQuery} placeholder="اسم الأنمي أو المانغا" placeholderTextColor="#888" style={{flex:1,color:'white',backgroundColor:'#292938',padding:10,borderRadius:10,textAlign:'right'}}/></View><View style={{flexDirection:'row',flexWrap:'wrap',marginTop:10}}>{watch.map(w=><TouchableOpacity key={w} onPress={()=>save(watch.filter(x=>x!==w))} style={{backgroundColor:'#39234f',padding:9,borderRadius:18,margin:3}}><Text style={{color:'#eee'}}>{w}  ×</Text></TouchableOpacity>)}</View></View>
 <View style={{flexDirection:'row',justifyContent:'space-between',marginTop:25,marginBottom:12}}><TouchableOpacity onPress={loadNews}><Text style={{color:'#bd9aff'}}>تحديث ↻</Text></TouchableOpacity><Text style={{color:'white',fontSize:21,fontWeight:'800'}}>{tab==='watch'?'أخبار متابعتي':'أحدث الأخبار'}</Text></View>
 {busy&&<ActivityIndicator color="#bd9aff"/>}{!busy&&shown.length===0&&<Text style={{color:'#999',textAlign:'center',padding:20}}>لا توجد أخبار بعد. شغّل الخادم وحاول التحديث.</Text>}
 {shown.map((n,i)=><TouchableOpacity key={n.id||i} onPress={()=>n.url&&Linking.openURL(n.url)} style={{backgroundColor:'#191925',padding:15,borderRadius:15,marginBottom:12}}><Text style={{color:'#bd9aff',textAlign:'right',fontSize:12}}>{n.source} • {n.published||''}</Text><Text style={{color:'white',fontSize:17,fontWeight:'800',textAlign:'right',marginTop:8}}>{n.title}</Text>{!!n.summary&&<Text style={{color:'#bbb',textAlign:'right',lineHeight:22,marginTop:8}}>{n.summary}</Text>}<Text style={{color:'#bd9aff',textAlign:'right',marginTop:10}}>قراءة من المصدر ←</Text></TouchableOpacity>)}
 <Text style={{color:'#666',fontSize:11,textAlign:'center',marginTop:12}}>سرعة التنبيه تعتمد على نشر المصدر واكتشاف التحديث.</Text>
 </ScrollView></SafeAreaView>;
}
