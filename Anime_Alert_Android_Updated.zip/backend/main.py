import asyncio,sqlite3,time,hashlib,os,json
from contextlib import asynccontextmanager
import feedparser,httpx
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
DB=os.getenv("DATABASE_PATH","anime_alert.db")
POLL_SECONDS=int(os.getenv("POLL_SECONDS","300"))
FEEDS=[
 ("Anime News Network","https://www.animenewsnetwork.com/all/rss.xml"),
 ("Crunchyroll News","https://www.crunchyroll.com/news/rss"),
 ("Manga Plus","https://mangaplus.shueisha.co.jp/rss"),
]
PUSH="https://exp.host/--/api/v2/push/send"
def conn():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
def init():
 with conn() as c:
  c.execute("CREATE TABLE IF NOT EXISTS articles(id TEXT PRIMARY KEY,title TEXT,summary TEXT,url TEXT,source TEXT,published TEXT,created REAL)")
  c.execute("CREATE TABLE IF NOT EXISTS devices(token TEXT PRIMARY KEY,watchlist TEXT,updated REAL)")
async def notify(token,title,summary,url):
 try:
  async with httpx.AsyncClient(timeout=12) as client:
   await client.post(PUSH,json={"to":token,"sound":"default","title":"Anime Alert • خبر جديد","body":title[:160],"data":{"url":url,"summary":summary[:500]}},headers={"Accept":"application/json","Content-Type":"application/json"})
 except Exception as e: print("Push error",e)
async def poll():
 for source,feed_url in FEEDS:
  try:
   parsed=feedparser.parse(feed_url)
   for item in parsed.entries[:50]:
    title=(item.get("title") or "خبر جديد").strip()
    summary=(item.get("summary") or item.get("description") or "")[:1200]
    url=item.get("link","");published=item.get("published","")
    aid=hashlib.sha256((url or title).encode()).hexdigest()
    with conn() as c:
     cur=c.execute("INSERT OR IGNORE INTO articles VALUES(?,?,?,?,?,?,?)",(aid,title,summary,url,source,published,time.time()))
     fresh=cur.rowcount>0
     devices=c.execute("SELECT token,watchlist FROM devices").fetchall() if fresh else []
    hay=(title+" "+summary).casefold()
    for d in devices:
     try: terms=json.loads(d["watchlist"] or "[]")
     except: terms=[]
     if any(str(t).strip().casefold() in hay for t in terms if str(t).strip()):
      await notify(d["token"],title,summary,url)
  except Exception as e: print("Feed error",source,e)
async def loop():
 while True:
  await poll()
  await asyncio.sleep(POLL_SECONDS)
@asynccontextmanager
async def lifespan(app):
 init();task=asyncio.create_task(loop())
 yield
 task.cancel()
app=FastAPI(title="Anime Alert API",lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_methods=["*"],allow_headers=["*"])
class Device(BaseModel):
 token:str
 watchlist:list[str]=[]
@app.get("/")
def root(): return {"app":"Anime Alert","status":"running","poll_seconds":POLL_SECONDS}
@app.get("/news")
def news():
 with conn() as c: rows=c.execute("SELECT * FROM articles ORDER BY created DESC LIMIT 100").fetchall()
 return [dict(x) for x in rows]
@app.post("/devices")
def register(d:Device):
 with conn() as c:
  c.execute("INSERT INTO devices VALUES(?,?,?) ON CONFLICT(token) DO UPDATE SET watchlist=excluded.watchlist,updated=excluded.updated",(d.token,json.dumps(d.watchlist,ensure_ascii=False),time.time()))
 return {"ok":True}
@app.post("/poll")
async def poll_now():
 await poll();return {"ok":True}
