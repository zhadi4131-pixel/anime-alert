# Anime Alert — Android APK starter

The project source is prepared. It is **not an installable APK yet**.

## Fastest path to an APK

You need a free Expo account and a computer with Node.js 20+.

1. Create/sign in to an Expo account at https://expo.dev/
2. Open a terminal in this `mobile` folder.
3. Run:
   ```bash
   npm install
   npx eas-cli login
   npx eas-cli build:configure
   ```
4. In `app.json`, replace `REPLACE_WITH_EAS_PROJECT_ID` with the project ID created by EAS (or let `eas build:configure` configure it).
5. Set the backend URL in a `.env` file based on `.env.example`.
6. Run:
   ```bash
   npx eas-cli build --platform android --profile preview
   ```
7. EAS will provide an APK download link when the cloud build finishes. Open that link on your Android phone and install the APK.

## Backend (required for live alerts)

Deploy the `backend` folder to an always-on Python host with HTTPS. Set `POLL_SECONDS=300`.
Then set `EXPO_PUBLIC_API_URL` to that backend's public HTTPS URL and rebuild the app.

For local backend testing:
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

## Current MVP scope and limitations

- Arabic dark-mode Android UI, personal anime/manga watchlist, news feed and followed-news filter.
- RSS polling backend (default every 5 minutes) and Expo push-notification registration.
- RSS sources can change or be unavailable; maintain the `FEEDS` list in `backend/main.py`.
- Keyword matching is basic and can miss aliases or produce false matches.
- Arabic automatic translation is not implemented in this starter.
- Real notifications require a physical Android device, notification permission, a configured Expo project, a deployed always-on backend and valid push credentials.
- The backend currently stores data in SQLite; for public production use add authentication, stronger matching, durable database backups, monitoring, privacy policy and source/licensing review.
